import json
import logging
import os
import hashlib
import uuid
import boto3
from botocore.config import Config

logger = logging.getLogger()
logger.setLevel(logging.INFO)

ORCHESTRATOR_AGENT_ARN = os.environ.get("ORCHESTRATOR_AGENT_ARN", "")
REGION = os.environ.get("AWS_REGION", "us-east-1")

agentcore = None


def get_client():
    global agentcore
    if agentcore is None:
        cfg = Config(
            read_timeout=900,
            connect_timeout=10,
            retries={"max_attempts": 1},
        )
        agentcore = boto3.client(
            "bedrock-agentcore", region_name=REGION, config=cfg
        )
    return agentcore


def handler(event, context):
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Content-Type": "application/json",
    }

    method = event.get("requestContext", {}).get("http", {}).get("method", "")
    if method == "OPTIONS":
        return {"statusCode": 200, "headers": headers, "body": ""}

    try:
        body = json.loads(event.get("body", "{}"))
    except Exception:
        return {
            "statusCode": 400,
            "headers": headers,
            "body": json.dumps({"error": "Invalid JSON"}),
        }

    user_message = body.get("message", "")
    session_id = body.get("sessionId", "")

    if not user_message:
        return {
            "statusCode": 400,
            "headers": headers,
            "body": json.dumps({"error": "No message"}),
        }
    if not ORCHESTRATOR_AGENT_ARN:
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": "Orchestrator not configured"}),
        }

    if session_id:
        session_uuid = str(
            uuid.UUID(hashlib.sha256(session_id.encode()).hexdigest()[:32])
        )
    else:
        session_uuid = str(uuid.uuid4())
    runtime_session_id = f"disruptionai-{session_uuid}"

    logger.info(
        "Invoking orchestrator: session=%s, msg_len=%d",
        runtime_session_id,
        len(user_message),
    )
    client = get_client()

    try:
        response = client.invoke_agent_runtime(
            agentRuntimeArn=ORCHESTRATOR_AGENT_ARN,
            runtimeSessionId=runtime_session_id,
            payload=json.dumps({
                "prompt": user_message,
                "session_id": session_id,
            }),
        )
    except Exception as e:
        logger.error("invoke_agent_runtime failed: %s", e, exc_info=True)
        return {
            "statusCode": 502,
            "headers": headers,
            "body": json.dumps({"error": str(e)}),
        }

    content_type = response.get("contentType", "")
    logger.info("Response contentType: %s", content_type)

    if "text/event-stream" in content_type:
        parts = []
        for line in response["response"].iter_lines(chunk_size=10):
            if line:
                decoded = (
                    line.decode("utf-8") if isinstance(line, bytes) else line
                )
                if decoded.startswith("data: "):
                    decoded = decoded[6:]
                if decoded.strip():
                    parts.append(decoded)
        resp_body = "".join(parts)
    elif content_type == "application/json":
        chunks = []
        for chunk in response.get("response", []):
            chunks.append(
                chunk.decode("utf-8") if isinstance(chunk, bytes) else chunk
            )
        resp_body = "".join(chunks)
    else:
        resp_body = response.get("response", b"")
        if hasattr(resp_body, "read"):
            resp_body = resp_body.read()
        if isinstance(resp_body, bytes):
            resp_body = resp_body.decode("utf-8")

    try:
        parsed = json.loads(resp_body)
        agent_reply = parsed.get("result", parsed.get("response", resp_body))
        agent_error = parsed.get("error")
    except (json.JSONDecodeError, TypeError):
        agent_reply = resp_body
        agent_error = None

    result = {
        "sessionId": runtime_session_id,
        "message": agent_reply,
        "error": agent_error,
    }
    logger.info("Returning response: len=%d", len(str(agent_reply)))
    return {
        "statusCode": 200,
        "headers": headers,
        "body": json.dumps(result),
    }
